Comments for instructors:
I like the documentation for this library. It provides
good example code that helped on this project. The lexer
keeps track of line numbers if you implement a t_newline function.
That is great functionality to have built in!

Attributions (if any):
www.dabeaz.com/ply/ply.html <-- lex documentation
