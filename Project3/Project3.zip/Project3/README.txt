Name:
Sean Joseph
Resources:
I cited a book a used to implement the singleton pattern in the source
class is called Tracker
PLY Docs
Professor Nahum's Proj2 Solution
Comments:
Was a nail-biter
