Name: Sean Joseph
Summary:
I got caught up by the literals vs token class 
issue for like a day and a half. That was a real
buzz kill. I remember that being an issue for the 
postfix demo. I should have been able to recall that.
External Resources (if any):
PLY documentation
