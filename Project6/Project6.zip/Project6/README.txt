Name:
Sean Joseph

Resources:
The slides on compiling bad commands into ugly code. Thanks Josh!

Comments:
Most of this assignment was easy to accomplish. Converting most of the 
bad instructions to ugly only required an extra line or two. I had an
extremely difficult time trying to get ar_copy and ar_set_size to work
the way I wanted them to. The debug mode for the ugly interpreter was
extremely useful when debugging my output ugly code. Even with the 
wonderful debug mode, I ended up spending the majority of my time on 
this project debugging my poor ugly code.
