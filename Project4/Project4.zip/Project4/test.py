from project import generate_bad_code_from_string

output = generate_bad_code_from_string(""" val x; x = 5; print(x);""")
print(output)
